using UnityEngine;

public class BonusScript : MonoBehaviour
{
    void Start() { }

    void Update()
    {
        transform.Rotate(0, 0.1f, 0);
    }
}